package com.infy.entity;
import javax.persistence.*;


@Entity
@Table(name="customer")
public class Customer {
	@Id
	private String uniqueIdNumber;
	private String dateOfBirth;
	private String emailAddress;
	private String firstName;
	private String lastName;
	private String idType;
	private String state;
	private String addressId;
	private int simId;
	
	
	public String getUniqueIdNumber() {
		return uniqueIdNumber;
	}

	public void setUniqueIdNumber(String uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getAddressId() {
		return addressId;
	}

	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}

	public int getSimId() {
		return simId;
	}
	public Customer()
	{
		
	}
	public Customer(String uniqueIdNumber, String dateOfBirth, String emailAddress, String firstName, String lastName,
			String idType, String state, String addressId, int simId) {
		super();
		this.uniqueIdNumber = uniqueIdNumber;
		this.dateOfBirth = dateOfBirth;
		this.emailAddress = emailAddress;
		this.firstName = firstName;
		this.lastName = lastName;
		this.idType = idType;
		this.state = state;
		this.addressId = addressId;
		this.simId = simId;
	}

	public void setSimId(int simId) {
		this.simId = simId;
	}





}
