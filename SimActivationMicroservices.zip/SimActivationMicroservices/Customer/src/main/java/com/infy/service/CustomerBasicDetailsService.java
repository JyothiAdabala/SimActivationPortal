package com.infy.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.entity.Customer;
import com.infy.exceptions.UserNotFoundException;
import com.infy.repository.CustomerRepository;
@Service
public class CustomerBasicDetailsService {
	@Autowired
	private CustomerRepository custverif;
	
	public String Customerdetailsverification(String email,String dob) throws UserNotFoundException {
			Customer obj=custverif.verifybasicdetails(email,dob);
			if(obj!=null) {
			return "success";
		}
			else{
			throw new UserNotFoundException("No request placed for you.");
		}
		
	}
}
