package com.infy.controller;

import java.util.Optional;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.infy.dto.CustomerBasicDetailsInputDto;
import com.infy.dto.CustomerDto;
import com.infy.dto.CustomerPersonalDetailsInputDto;
import com.infy.service.CustomerBasicDetailsService;
import com.infy.service.CustomerPersonalDetailsService;
import com.infy.service.CustomerValidationService;



@RestController
public class CustomerController {



//1.Customer Basic Details 	
	@Autowired
	 private CustomerBasicDetailsService basicdetails;

	@PostMapping("/customer_basic_details")
	public  String Customerdetailsverification(@Valid @RequestBody CustomerBasicDetailsInputDto cdip) throws Exception 
   {
			String obj=basicdetails.Customerdetailsverification(cdip.getEmail(),cdip.getDob());
			return obj;
		}
	
	
//2.Customer Personal Details
	@Autowired
	private CustomerPersonalDetailsService customerdetails;
	@PostMapping("/customer_personal_details")
	public  String Customerpersonaldetailsverification(@Valid @RequestBody  CustomerPersonalDetailsInputDto cdip) throws Exception 
   {
			String obj=customerdetails.Customerpersonaldetailsverification(cdip.getFirstname(),cdip.getLastname(),cdip.getEmail());
			return  obj;
		}
	
	
// 3.Get Customer Details
	@Autowired
	private CustomerValidationService custdetails;

	@GetMapping("/customer_validation/{uniqueid}/{firstname}/{lastname}")
	public  Optional<CustomerDto> Updatedetails(@PathVariable String uniqueid,@PathVariable String firstname,@PathVariable String lastname)  
   {	
		Optional<CustomerDto> obj=custdetails.Customerdetailsverification(uniqueid,firstname,lastname);
		if(obj!=null) {
			return obj; 
		}
		else {
			return null;
		}
			
		}


}
