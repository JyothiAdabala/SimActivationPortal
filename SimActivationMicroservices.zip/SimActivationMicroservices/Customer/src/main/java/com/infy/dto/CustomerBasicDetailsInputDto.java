package com.infy.dto;

import javax.validation.constraints.*;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

public class CustomerBasicDetailsInputDto {
	@NotNull(message = "email cannot be null")
	@NotEmpty(message="Email value is required")
	@Pattern(regexp="^[A-z]*[A-z 0-9.][@]([A-z]*)[.][A-z]{2,3}",message="Invalid email")
	private String email;

	@NotNull(message = "Date Of Birth cannot be null")
	@NotEmpty(message="date of birth value is required")
	@JsonFormat(pattern ="yyyy-MM-dd",shape=Shape.STRING)
	@Pattern(regexp="[0-9]{4}[-][0-9]{2}-[0-9]{2}",message="Invalid Date_of_Birth, should be in Pattern yyyy-mm-dd")
	private String dob;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}




}
