package com.infy.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class CustomerPersonalDetailsInputDto {
	
	@NotNull(message = "Firstname canot be null")
@Size(max=15, message="Firstname should be maximum of 15 characters")
 private String firstname;
	
	
	
@NotNull(message = "lastName canot be null")
@Size(max=15, message="Lastname should be maximum of 15 characters")
 private String lastname;


@NotNull(message = "email cannot be null")
@NotEmpty(message="Email value is required")
@Pattern(regexp="^[A-z]*[A-z 0-9.][@]([A-z]*)[.][A-z]{2,3}",message="Invalid email")
 private String email;
 
 public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}

}
