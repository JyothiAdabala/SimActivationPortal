package com.infy.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class SimDetailsDto {
	int simId;
	public int getSimId() {
		return simId;
	}
	public void setSimId(int simId) {
		this.simId = simId;
	}
	public String getServiceNumber() {
		return serviceNumber;
	}
	public void setServiceNumber(String serviceNumber) {
		this.serviceNumber = serviceNumber;
	}
	public String getSimNumber() {
		return simNumber;
	}
	public void setSimNumber(String simNumber) {
		this.simNumber = simNumber;
	}
	public String getSimStatus() {
		return simStatus;
	}
	public void setSimStatus(String simStatus) {
		this.simStatus = simStatus;
	}
	@NotEmpty(message="SERVICENUMBER value is required")
	@Size(min = 10, max = 10, message = "Service NUMBER SHOULD HAVE 10 DIGITS")
	private String serviceNumber;
	@NotEmpty(message="SIM NUMBER value is required")
	@Size(min = 13, max = 13, message = "SIM NUMBER SHOULD HAVE 13 DIGITS")
	private String simNumber;
	private String simStatus;
}
