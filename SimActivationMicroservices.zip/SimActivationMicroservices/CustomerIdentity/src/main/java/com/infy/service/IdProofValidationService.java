package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.infy.dto.CustomerDto;
import com.infy.dto.CustomerIdentityDto;
import com.infy.dto.SimDetailsDto;
import com.infy.entity.CustomerIdentity;
import com.infy.exceptions.UserNotFoundException;
import com.infy.repository.CustomerIdentityRepository;

@Service
public class IdProofValidationService {
	@Autowired
	private CustomerIdentityRepository cidentityrpose;
	
	
	
	public SimDetailsDto simActive(CustomerIdentityDto ci) throws UserNotFoundException{
		CustomerIdentity obj1= new CustomerIdentity();
		
		// checking for valid first name and last name and unique id
		obj1=cidentityrpose.verifyidfirstandlastname(ci.getUniqueIdNumber(),ci.getFirstName(),ci.getLastName());
		CustomerDto obj2=new RestTemplate().getForObject("http://localhost:9003/simactivation/customer_validation/"+ci.getUniqueIdNumber()+"/"+ci.getFirstName()+"/"+ci.getLastName(),CustomerDto.class);
		
		
		if((obj1==null) || (obj2==null)) {
			throw new UserNotFoundException("Invalid details");
		}
		if( (!(obj1.getDateOfBirth().equalsIgnoreCase(ci.getDateOfBirth()))  || (!((obj2.getDateOfBirth().equalsIgnoreCase(ci.getDateOfBirth()))))) ) {
			throw new UserNotFoundException("Incorrect date of birth details");
		}
		
		
		SimDetailsDto obj3=new RestTemplate().getForObject("http://localhost:9001/simactivation/sim_validation/"+obj2.getSimId(),SimDetailsDto.class);
		return obj3;
		
	}
}
