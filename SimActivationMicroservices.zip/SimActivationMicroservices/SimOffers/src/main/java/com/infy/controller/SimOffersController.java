package com.infy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.infy.dto.SimOffersDto;
import com.infy.service.SimOffersService;

@CrossOrigin
@RestController
public class SimOffersController {
	 
// 1. SIM Offers
	@Autowired
	private SimOffersService simserv;
	@GetMapping("/sim_offers/{simId}")
	public  SimOffersDto simActiveStatus(@PathVariable Integer simId){
			SimOffersDto obj=simserv.getOffers(simId);
			return obj;
		}


}
