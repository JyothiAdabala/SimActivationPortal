package com.infy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.infy.entity.SimOffers;



@Repository
public interface SimOffersRepository extends JpaRepository<SimOffers, Integer>{
	
	@Query(value="SELECT *FROM sim_offers WHERE sim_id=:simId" ,nativeQuery=true)
	SimOffers findOffers(@Param("simId")Integer simId);
	


}
