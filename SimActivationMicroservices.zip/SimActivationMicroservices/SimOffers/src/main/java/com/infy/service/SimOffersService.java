package com.infy.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infy.dto.SimOffersDto;
import com.infy.entity.SimOffers;
import com.infy.repository.SimOffersRepository;

@Service
public class SimOffersService {
	@Autowired
	private SimOffersRepository simrepository;
	
	@Autowired
	private ModelMapper modelMapper;

	public SimOffersDto getOffers(Integer simId) {
		SimOffers obj=simrepository.findOffers(simId);
		SimOffersDto obj1=modelMapper.map(obj,SimOffersDto.class);
		return obj1;
	}
}