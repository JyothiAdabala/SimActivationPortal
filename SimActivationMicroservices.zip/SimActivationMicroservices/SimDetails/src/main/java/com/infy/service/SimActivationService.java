package com.infy.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infy.dto.SimDetailsDto;
import com.infy.entity.SimDetails;
import com.infy.repository.SimDetailsRepository;

@Service
public class SimActivationService {
	@Autowired
	private SimDetailsRepository simrepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public Optional<SimDetailsDto> simstatus(Integer simId) {
		Optional<SimDetails> obj=simrepository.findById(simId);
		SimDetails obj2=obj.get();
		if(obj2!=null) {
			if(obj2.getSimStatus().equalsIgnoreCase("inactive")) {
				obj2.setSimStatus("active");
				
				SimDetails obj3=simrepository.save(obj2);
				return Optional.of(modelMapper.map(obj3,SimDetailsDto.class));
			}
			else {
				return Optional.of(modelMapper.map(obj2,SimDetailsDto.class));
			}
		}
		else {
			return null;
		}
		
		
	}
}
