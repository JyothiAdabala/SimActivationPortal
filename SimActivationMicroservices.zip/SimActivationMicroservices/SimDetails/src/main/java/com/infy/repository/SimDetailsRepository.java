package com.infy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infy.entity.SimDetails;
@Repository
public interface SimDetailsRepository extends JpaRepository<SimDetails, Integer>{
	
	@Query(value="SELECT *FROM sim_details WHERE service_number= :serviceNumber and sim_number=:simNo" ,nativeQuery=true)
	SimDetails findStatus(@Param("serviceNumber") String serviceNumber,@Param("simNo")String simNo);
	


}
