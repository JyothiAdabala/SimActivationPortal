package com.infy.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infy.dto.SimDetailsDto;
import com.infy.dto.SimDetailsInputDto;
import com.infy.dto.SimOffersDto;
import com.infy.service.SimActivationService;
import com.infy.service.SimDetailsService;


@CrossOrigin
@RestController
public class SimDetailsController {

// 1. SIM Details
	@Autowired
	private SimDetailsService simserv;
	@PostMapping("/sim_details")
	public  ResponseEntity<SimOffersDto> simActiveStatus( @Valid @RequestBody  SimDetailsInputDto cdto) throws Exception 
   {
			SimOffersDto obj=simserv.simValidation(cdto.getSimNumber(),cdto.getServiceNumber());
			return new ResponseEntity<>(obj,HttpStatus.OK);
		}
	
	
//2. SIM Validation
	
	@Autowired
	private SimActivationService simactserv;
	@GetMapping("/sim_validation/{simId}")
	public  Optional<SimDetailsDto> simvalidation(@PathVariable Integer simId)  
   {
			Optional<SimDetailsDto> obj=simactserv.simstatus(simId);
			return obj;
		}
	
}
