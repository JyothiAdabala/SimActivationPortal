package com.infy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.*;

import com.infy.model.SimOffers;
import com.infy.service.SimOffersService;

@RestController
@EnableAutoConfiguration
@RequestMapping(value="/offers")
public class SimOffersController {
	
	@Autowired
	SimOffersService simOffersService;
	
	@GetMapping
	SimOffersService demo() {
		simOffersService.getAllSimOffers();
		return simOffersService;
	}
	
	@PostMapping
	SimOffers save(@RequestBody SimOffers simOffers) {
		simOffersService.saveOrUpdate(simOffers);
		return simOffers;
		
	}

}
