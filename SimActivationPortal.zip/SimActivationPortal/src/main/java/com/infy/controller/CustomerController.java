package com.infy.controller;

import java.time.LocalDate;
import java.util.*;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.Customer;
import com.infy.model.SimDetails;
import com.infy.repository.CustomerRepo;
import com.infy.service.CustomerService;

@RestController
@EnableAutoConfiguration
@RequestMapping(value="/customer")
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	CustomerRepo repo;
	
	String dob = null;
	String email=null,val1=null,val2=null,val3=null;
	@PostMapping("/data")
	public String save1(@Valid @RequestBody Customer customer) {
//		service.saveOrUpdate(simDetails);
//		return customer;
		dob = customer.getDateOfBirth();
		email=customer.getEmail();
		val1 = repo.match(dob,email);
		if(val1==null) {
			return "No request placed for you";
		}
		else {
		return "Data present";
		}
	}
	@PostMapping("/findcustomer")
	public String save2(@RequestBody Customer customer) {
		
		String firstName = customer.getFname();
		String lastName = customer.getLname();
		String email = customer.getEmail();
		val2 = repo.names(firstName,lastName);
		val3 = repo.confirmEmail(email);
		if(val2 == null) {
			return "No customer found for the provided details";
		}if(val3 == null) {
			return "Invalid email details";
		}
		return "Customer found";
	}
	
	

}
