package com.infy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.*;

import com.infy.model.SimDetails;
import com.infy.repository.SimDetailsRepository;
import com.infy.repository.SimOffersRepository;
import com.infy.service.SimDetailsService;

@RestController
@EnableAutoConfiguration
@RequestMapping(value="/details")
public class SimDetailsController {
	
	@Autowired
	SimDetailsService simDetailsService;
	 @Autowired
	    SimOffersRepository repository;
	    
	    @Autowired
	    SimDetailsRepository rep;
		
	    String s1=null,s2=null;
		@PostMapping
		public String save(@RequestBody SimDetails simDetails) {
			//service.saveOrUpdate(simDetails);
			
			s1=simDetails.getServiceNumber();
			s2 = simDetails.getSimNumber();
			return repository.offers(s1, s2)+" "+"and"+" "+repository.status(s1,s2);
			
		}
		

}
