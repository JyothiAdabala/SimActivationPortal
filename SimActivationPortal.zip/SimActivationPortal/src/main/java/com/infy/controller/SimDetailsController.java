package com.infy.controller;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.infy.exception.SimDetailsException;
import com.infy.model.SimDetails;
import com.infy.repository.SimDetailsRepository;
import com.infy.repository.SimOffersRepository;
import com.infy.service.SimDetailsService;
//import com.simactivation.Entity.SimOffers;

@RestController
@EnableAutoConfiguration
@RequestMapping(value="/detail")
public class SimDetailsController {
	
	@Autowired
	SimDetailsService simDetailsService;
	 @Autowired
	    SimOffersRepository repository;
	    
	    @Autowired
	    SimDetailsRepository rep;
		
	    String s1=null,s2=null,status=null;
		@PostMapping
		public String save(@Valid @RequestBody SimDetails simDetails) throws SimDetailsException{
			//service.saveOrUpdate(simDetails);
		
			s1=simDetails.getServiceNumber();
			s2 = simDetails.getSimNumber();
			status = repository.status(s1,s2);
			if(status.equals("active")) {
				return (repository.offers(s1, s2)+" "+"and"+" Sim is already active");

			}
			return repository.offers(s1, s2);
			
		}
		

}
