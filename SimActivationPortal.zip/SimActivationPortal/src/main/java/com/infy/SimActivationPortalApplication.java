package com.infy;

import java.sql.Date;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.infy.model.Customer;
import com.infy.model.CustomerAddress;
import com.infy.model.SimDetails;
import com.infy.model.SimOffers;
import com.infy.repository.CustomerAddRepo;
import com.infy.repository.CustomerRepo;
import com.infy.repository.SimDetailsRepository;
import com.infy.repository.SimOffersRepository;

@SpringBootApplication
public class SimActivationPortalApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SimActivationPortalApplication.class, args);
	}

	@Autowired
	SimOffersRepository simOffersRepository;
	
	@Autowired
	SimDetailsRepository simDetailsRepository;
	
	@Autowired
	CustomerAddRepo customerAddRepo;
	
	@Autowired
	CustomerRepo customer;
	
	@Override
	public void run(String... args) throws Exception {
			
		SimDetails details1 = new SimDetails();
		details1.setServiceNumber("1234567891");
		details1.setSimNumber("1234567891234");
		details1.setSimStatus("active");
		
		SimDetails details2 = new SimDetails();
		details2.setServiceNumber("1234567892");
		details2.setSimNumber("1234567891235");
		details2.setSimStatus("inactive");
		
		SimOffers offers1 = new SimOffers();
		offers1.setCallQty(100);
		offers1.setCost(100);
		offers1.setDataQty(120);
		offers1.setDuration(10);
		offers1.setOfferName("Free calls and data");
		offers1.setSimDetails(details1);
		
		SimOffers offers2 = new SimOffers();
		offers2.setCallQty(150);
		offers2.setCost(50);
		offers2.setDataQty(100);
		offers2.setDuration(15);
		offers2.setOfferName("Free calls");
		offers2.setSimDetails(details2);
		
		details1.setSimOffers(offers1);
		details2.setSimOffers(offers2);
	
		
		simOffersRepository.save(offers1);
		simOffersRepository.save(offers2);
		
		CustomerAddress custadd1 = new CustomerAddress();
		custadd1.setAddr("Jayanagar");
		custadd1.setCity("Bangalore");
		custadd1.setPincode(560041);
		custadd1.setState("Karnataka");
		
		CustomerAddress custadd2 = new CustomerAddress();
		custadd2.setAddr("Vijaynagar");
		custadd2.setCity("Mysore");
		custadd2.setPincode(567017);
		custadd2.setState("Karna");
		
		customerAddRepo.save(custadd1);
		customerAddRepo.save(custadd2);
		
		Customer cust1 = new Customer();
		cust1.setUniqueIdNumber("1234567891234567");
		cust1.setDateOfBirth("1990-12-12");
		cust1.setEmail("smith@abc.com");
		cust1.setFname("Smith");
		cust1.setLname("John");
		cust1.setIdType("Aadhar");
		cust1.setSimDetails(details1);
		cust1.setCustomerAddress(custadd1);
		
		custadd1.setCustomer(cust1);
		
		Customer cust2 = new Customer();
		cust2.setUniqueIdNumber("1234567891234568");
		cust2.setDateOfBirth("1998-12-12");
		cust2.setEmail("bob@abc.com");
		cust2.setFname("Bob");
		cust2.setLname("Sam");
		cust2.setIdType("Aadhar");
		cust2.setSimDetails(details2);
		cust2.setCustomerAddress(custadd2);
		
		custadd2.setCustomer(cust2);
		

		
		customer.save(cust1);
		customer.save(cust2);
		
		
		 
	}

}
