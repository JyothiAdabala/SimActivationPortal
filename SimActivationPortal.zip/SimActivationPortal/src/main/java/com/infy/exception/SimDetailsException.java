package com.infy.exception;


public class SimDetailsException extends Exception {
	

	private static final long serialVersionUID = 1L;

	public SimDetailsException(String msg) {
		super(msg);
	}
	
}
