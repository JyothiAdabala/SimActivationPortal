package com.infy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.infy.model.SimOffers;


@Repository
public interface SimOffersRepository extends JpaRepository<SimOffers,Long>{
	
	@Query(value="select offer_name from sim_offers SO, sim_details SD where SO.sim_id=SD.id and service_number= :s1 and sim_number=:s2",nativeQuery=true)
	public String offers(@Param("s1") String s1,@Param("s2") String s2);
	
	@Query(value="select sim_status from sim_details S where S.service_number= :s1 and S.sim_number=:s2",nativeQuery=true)
	public String status(@Param("s1") String s1,@Param("s2") String s2);


}
