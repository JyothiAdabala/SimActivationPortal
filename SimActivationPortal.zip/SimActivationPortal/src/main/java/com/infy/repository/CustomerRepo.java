package com.infy.repository;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.infy.model.Customer;


@Repository
public interface CustomerRepo extends CrudRepository<Customer,Long>{

	@Query(value="select unique_id_number from customer where customer.date_of_birth = :s1 and customer.email = :s2",nativeQuery=true)
	public String match(@Param("s1") String s1,@Param("s2") String s2);
	
	@Query(value="select unique_id_number from customer C where C.fname = :s1 and C.lname = :s2",nativeQuery=true)
	public String names(@Param("s1") String s1,@Param("s2") String s2);
	
	@Query(value="select unique_id_number from customer C where C.email=:s",nativeQuery=true)
	public String confirmEmail(@Param("s") String s);
	
}
