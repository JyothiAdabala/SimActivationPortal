package com.infy.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.infy.model.SimDetails;


@Repository
public interface SimDetailsRepository extends CrudRepository<SimDetails,Long>{

}
