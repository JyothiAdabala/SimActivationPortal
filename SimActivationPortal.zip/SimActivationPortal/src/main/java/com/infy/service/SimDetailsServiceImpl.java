package com.infy.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.model.SimDetails;
import com.infy.repository.SimDetailsRepository;


@Service(value = "simDetailsService")
@Transactional
public class SimDetailsServiceImpl implements SimDetailsService{
	
	@Autowired
	SimDetailsRepository simDetailsRepo;

	@Override
	public List<SimDetails> getAllSimDetails() {
		// TODO Auto-generated method stub
		return (List<SimDetails>)simDetailsRepo.findAll();
	}

	@Override
	public SimDetails getById(Long id) {
		// TODO Auto-generated method stub
		return simDetailsRepo.findById(id).get();
	}

	@Override
	public void saveOrUpdate(SimDetails simDetails) {
		// TODO Auto-generated method stub
		simDetailsRepo.save(simDetails);
	}

}
