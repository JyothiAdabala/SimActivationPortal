package com.infy.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.model.SimOffers;
import com.infy.repository.SimOffersRepository;


@Service
@Transactional
public class SimOffersServiceImpl implements SimOffersService{
	
	@Autowired
	SimOffersRepository simOffersRepo;

	@Override
	public List<SimOffers> getAllSimOffers() {
		// TODO Auto-generated method stub
		return (List<SimOffers>)simOffersRepo.findAll();
	}

	@Override
	public SimOffers getById(Long id) {
		// TODO Auto-generated method stub
		return simOffersRepo.findById(id).get();
	}

	@Override
	public void saveOrUpdate(SimOffers simOffers) {
		// TODO Auto-generated method stub
		simOffersRepo.save(simOffers);
	}

}
