package com.infy.service;

import java.util.List;

import com.infy.model.SimOffers;

public interface SimOffersService {
	
public List<SimOffers> getAllSimOffers();
	
SimOffers getById(Long id);
	
	void saveOrUpdate(SimOffers simOffers);
}
