package com.infy.service;

import java.io.*;
import java.util.*;

import com.infy.model.SimDetails;

public interface SimDetailsService {
	
	public List<SimDetails> getAllSimDetails();
	
	SimDetails getById(Long id);
	
	void saveOrUpdate(SimDetails simDetails);
}
