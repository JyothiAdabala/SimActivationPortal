package com.infy.model;

import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
@Table
public class CustomerAddress {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int addId;
	
	@Size(max=25,message="Address should be maximum of 25 characters")
	String addr;
	
	@Pattern(regexp="^[a-zA-Z ]*$",message="City/State should not contain any special characters expect space")
	String city,state;
	
	@Size(max=6,message="Pin should be 6 digit number")
	String pincode;
	
	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER,mappedBy = "customerAddress")
	Customer customer;
	
	public CustomerAddress() {}

	public CustomerAddress(String addr, String city, String state, String pincode) {
		super();
		this.addr = addr;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}

	public int getAddId() {
		return addId;
	}

	public void setAddId(int addId) {
		this.addId = addId;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	

}
