package com.infy.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.*;
import javax.validation.constraints.AssertFalse.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table
@JsonIgnoreProperties(value= {"details","address"})
public class Customer {
	
	@Id
	String uniqueIdNumber;

	
	@JsonFormat(pattern="yyyy-MM-dd",shape=Shape.STRING)
	@NotBlank(message="Dob value is required")
	String dateOfBirth;
	
	
	@Email(message="Invalid email",regexp="^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@"+"[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$")
	@NotEmpty(message = "Email value is required")
	String email;
	
	@Pattern(regexp="^[A-Za-z]*$",message="Firstname/Lastname should contain only alphabets")
	@Size(max=15,message="Firstname/Lastname should be maximum of 15 characters")
	String fname,lname;
	String idType;
	
	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name = "simId")
	SimDetails simDetails;
	
	@OneToOne(cascade = CascadeType.MERGE,fetch = FetchType.EAGER)
	@JoinColumn(name = "addId")
	CustomerAddress customerAddress;
	
	public Customer() {}

	public Customer(String dateOfBirth, String email, String fname, String lname, String idType,
			CustomerAddress customerAddress) {
		super();
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.fname = fname;
		this.lname = lname;
		this.idType = idType;
		this.customerAddress = customerAddress;
	}

	
	public String getUniqueIdNumber() {
		return uniqueIdNumber;
	}

	public void setUniqueIdNumber(String uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public CustomerAddress getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(CustomerAddress customerAddress) {
		this.customerAddress = customerAddress;
	}

	public SimDetails getSimDetails() {
		return simDetails;
	}

	public void setSimDetails(SimDetails simDetails) {
		this.simDetails = simDetails;
	}

	
	
}
