package com.infy.model;

import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
@Table
public class SimDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	@NotEmpty
	@Size(max=10,message="Invalid details, please check again Service number!")
	String serviceNumber;
	@NotEmpty
	@Size(max=13,message="Invalid details, please check again SIM number!")
	String simNumber;
	
	String simStatus;
	
	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER,mappedBy = "simDetails")
	SimOffers simOffers;
	
	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER,mappedBy = "simDetails")
	Customer customer;
	
	public SimDetails() {}

	public SimDetails(String serviceNumber, String simNumber, String simStatus) {
		super();
		this.serviceNumber = serviceNumber;
		this.simNumber = simNumber;
		this.simStatus = simStatus;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getServiceNumber() {
		return serviceNumber;
	}

	public void setServiceNumber(String serviceNumber) {
		this.serviceNumber = serviceNumber;
	}

	public String getSimNumber() {
		return simNumber;
	}

	public void setSimNumber(String simNumber) {
		this.simNumber = simNumber;
	}

	public String getSimStatus() {
		return simStatus;
	}

	public void setSimStatus(String simStatus) {
		this.simStatus = simStatus;
	}

	public SimOffers getSimOffers() {
		return simOffers;
	}

	public void setSimOffers(SimOffers simOffers) {
		this.simOffers = simOffers;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	

}
