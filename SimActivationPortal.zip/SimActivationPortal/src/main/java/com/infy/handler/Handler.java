package com.infy.handler;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.infy.ErrorInfo.ErrorInfo;
import com.infy.exception.SimDetailsException;

@RestControllerAdvice
public class Handler {
	
	@Autowired
	Environment environment;
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorInfo> check(MethodArgumentNotValidException ex){
		
		ErrorInfo error = new ErrorInfo();
		
		error.setErrorCode(HttpStatus.BAD_REQUEST.value());
		
		String errorMsg = ex.getBindingResult().getAllErrors().stream().map(x-> x.getDefaultMessage()).collect(Collectors.joining(", "));
		 error.setErrorMessage(errorMsg);
		
		return new ResponseEntity<ErrorInfo>(error,HttpStatus.BAD_REQUEST);
		
	}

}
